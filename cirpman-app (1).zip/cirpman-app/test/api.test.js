const {spawn}=require('child_process');
const os=require('os'),fs=require('fs'),path=require('path');const DD=fs.mkdtempSync(path.join(os.tmpdir(),'cirpman-test-'));const srv=spawn('node',['--no-warnings','server.js'],{env:{...process.env,PORT:'3999',DATA_DIR:DD,ADMIN_PASSWORD:'TestAdminPass1'},cwd:path.join(__dirname,'..')});
let log='';srv.stdout.on('data',d=>log+=d);srv.stderr.on('data',d=>log+=d);
const B='http://localhost:3999';
async function api(m,p,body,tok){const r=await fetch(B+p,{method:m,headers:{'Content-Type':'application/json',...(tok?{Authorization:'Bearer '+tok}:{})},body:body?JSON.stringify(body):undefined});let j={};try{j=await r.json()}catch{}return {s:r.status,...j}}
let pass=0,fail=0;const ok=(n,c,x)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n+(c?'':' -> '+JSON.stringify(x)))};
const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
(async()=>{
 await new Promise(r=>setTimeout(r,800));
 let r=await api('GET','/api/public');ok('public bootstrap',r.s===200&&r.estates.length===5&&!('settings' in r),r);
 r=await api('GET','/api/admin/data');ok('admin data blocked without token',r.s===401,r);
 r=await api('POST','/api/admin/login',{password:'wrong'});ok('bad admin pw rejected',r.s===401,r);
 r=await api('POST','/api/admin/login',{password:'TestAdminPass1'});ok('admin login',r.s===200&&r.token,r);const A=r.token;
 // subscribe: price from server
 const e=(await api('GET','/api/public')).estates[0];
 r=await api('POST','/api/subscribe',{name:'Ada Obi',email:'ada@x.com',phone:'08031234567',estateId:e.id,plotIndex:0,plan:'outright',method:'bank',ref:'',amount:1});
 ok('subscribe ok',r.s===200&&r.payment.amount===e.plots[0].outright&&r.tempPassword,r);const pay=r.payment;
 ok('client passhash not leaked',!JSON.stringify(r).includes('scrypt'),r);
 r=await api('POST','/api/subscribe',{name:'',email:'bad',phone:'1',estateId:e.id,plotIndex:0});ok('subscribe validation',r.s===400,r);
 // consultant
 const reg={name:'Chi Cons',email:'chi@x.com',phone:'08099990000',password:'secret12',cause:'Earn',passport:png,upline:''};
 r=await api('POST','/api/consultant/register',reg);ok('consultant register',r.s===200,r);
 r=await api('POST','/api/consultant/register',reg);ok('duplicate register 409',r.s===409,r);
 r=await api('POST','/api/consultant/login',{username:'chi@x.com',password:'secret12'});ok('pending login 403 PENDING',r.s===403&&r.code==='PENDING',r);
 let d=(await api('GET','/api/admin/data',null,A));ok('admin data',d.consultants.length===1&&!JSON.stringify(d).includes('passHash'),Object.keys(d));
 const cid=d.consultants[0].id;
 r=await api('POST','/api/admin/consultants/'+cid+'/activate',null,A);ok('activate gives ID',/^CH\/IC\/\d\d\/0001$/.test(r.consultantId),r);const CID=r.consultantId;
 r=await api('POST','/api/consultant/login',{username:'08099990000',password:'secret12'});ok('login by phone',r.s===200&&r.token,r);const C=r.token;
 r=await api('GET','/api/consultant/me',null,C);ok('consultant me',r.s===200&&r.consultant.consultantId===CID&&!('passHash' in r.consultant),r);
 r=await api('GET','/api/admin/data',null,C);ok('consultant token cannot read admin data',r.s===401,r);
 r=await api('POST','/api/admin/sync',{collection:'estates',upserts:[]},C);ok('consultant cannot sync',r.s===401,r);
 // sale
 r=await api('POST','/api/consultant/sales',{estateId:e.id,plotSize:e.plots[0].size,amount:1000000,clientName:'Buyer One',clientPhone:'0803',receipt:{data:png,type:'image'}},C);
 ok('submit sale',r.s===200&&r.sale.ref==='SL-0001'&&r.sale.estateType===e.type,r);const sid=r.sale.id;
 r=await api('POST','/api/admin/sales/'+sid+'/reject',{reason:''},A);ok('reject needs reason',r.s===400,r);
 r=await api('POST','/api/admin/sales/'+sid+'/reject',{reason:'blurry'},A);ok('reject',r.s===200,r);
 r=await api('POST','/api/consultant/sales/'+sid+'/resubmit',{receipt:{data:png,type:'image'}},C);ok('resubmit',r.s===200&&r.sale.status==='Pending',r);
 r=await api('POST','/api/admin/sales/'+sid+'/approve',null,A);ok('approve creates commission',r.s===200&&r.entries===1,r);
 r=await api('POST','/api/admin/sales/'+sid+'/approve',null,A);ok('double approve blocked',r.s===400,r);
 r=await api('GET','/api/consultant/me',null,C);const rate=e.type==='easybuy'?7:10;ok('consultant sees commission',r.commissions.length===1&&r.commissions[0].amount===1000000*rate/100,r.commissions);
 // payment mark paid + referral commission
 r=await api('POST','/api/admin/payments/'+pay.id+'/mark-paid',null,A);ok('mark paid',r.payment.status==='Paid',r);
 // referral via consultant ID
 const e2=e;r=await api('POST','/api/subscribe',{name:'Bola',email:'b@x.com',phone:'08031112222',estateId:e2.id,plotIndex:0,plan:'outright',method:'bank',ref:CID});
 await api('POST','/api/admin/payments/'+r.payment.id+'/mark-paid',null,A);
 d=await api('GET','/api/admin/data',null,A);ok('referral commission via consultant ID',d.commissions.filter(c=>c.staffRef===CID).length===2,d.commissions.length);
 // DEACTIVATE
 r=await api('POST','/api/admin/consultants/'+cid+'/deactivate',null,A);ok('deactivate',r.s===200,r);
 r=await api('GET','/api/consultant/me',null,C);ok('old token revoked immediately (403 INACTIVE)',r.s===403&&r.code==='INACTIVE',r);
 r=await api('POST','/api/consultant/sales',{estateId:e.id,plotSize:e.plots[0].size,amount:5,clientName:'x',receipt:{data:png}},C);ok('cannot submit sale when inactive',r.s===403,r);
 r=await api('POST','/api/consultant/login',{username:'chi@x.com',password:'secret12'});ok('cannot log in when inactive',r.s===403&&r.code==='INACTIVE',r);
 d=await api('GET','/api/admin/data',null,A);ok('status stored Inactive',d.consultants[0].status==='Inactive');
 r=await api('POST','/api/admin/consultants/'+cid+'/reactivate',null,A);ok('reactivate',r.s===200);
 r=await api('GET','/api/consultant/me',null,C);ok('works again after reactivation',r.s===200,r);
 // upload + gallery sync
 r=await api('POST','/api/admin/upload',{data:'data:image/svg+xml;base64,PHN2Zz48L3N2Zz4='},A);ok('svg upload rejected',r.s===400,r);
 r=await api('POST','/api/admin/upload',{data:png},A);ok('image upload',r.s===200&&r.url.startsWith('/uploads/'),r);
 const f=await fetch(B+r.url);ok('uploaded file served',f.status===200&&f.headers.get('content-type')==='image/png');
 r=await api('POST','/api/admin/upload',{data:'data:video/mp4;base64,AAAAIGZ0eXBpc29t'},A);ok('video upload',r.s===200&&r.type==='video',r);
 // settings
 r=await api('PUT','/api/admin/settings',{paystack:'pk_test_x',password:'short'},A);ok('short admin pw rejected',r.s===400,r);
 r=await api('PUT','/api/admin/settings',{paystack:'pk_test_x',password:'NewStrongPass9'},A);ok('settings saved',r.s===200);
 r=await api('POST','/api/admin/login',{password:'NewStrongPass9'});ok('new admin pw works',r.s===200);
 r=await api('GET','/api/public');ok('public paystack key but no secret',r.paystackKey==='pk_test_x'&&!JSON.stringify(r).includes('paystackSecret'));
 r=await api('POST','/api/paystack/verify',{paymentId:'nope',reference:'x'});ok('verify unknown payment 404',r.s===404,r);
 // traversal / static
 let t=await fetch(B+'/..%2f..%2fserver.js');ok('path traversal blocked',t.status!==200,t.status);
 t=await fetch(B+'/server.js');ok('server.js not served',t.status===404,t.status);
 t=await fetch(B+'/data/cirpman.db');ok('db not served',t.status===404,t.status);
 // rate limit
 let last;for(let i=0;i<10;i++)last=await api('POST','/api/admin/login',{password:'x'});ok('admin login rate-limited',last.s===429,last);
 console.log(`\n${pass} passed, ${fail} failed`);srv.kill();process.exit(fail?1:0);
})().catch(e=>{console.error(e,log);srv.kill();process.exit(2)});
